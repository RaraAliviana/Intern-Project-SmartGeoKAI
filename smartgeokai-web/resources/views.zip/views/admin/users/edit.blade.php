@extends('layouts.app')

@section('title', 'Edit Petugas')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-4">
        Edit Petugas
    </h2>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="mb-3">

                <label class="form-label">
                    Nama Lengkap
                </label>

                <input
                    type="text"
                    class="form-control"
                    value="Petugas Demo"
                >

            </div>


            <div class="mb-3">

                <label class="form-label">
                    Username
                </label>

                <input
                    type="text"
                    class="form-control"
                    value="petugasdemo"
                >

            </div>


            <div class="mb-3">

                <label class="form-label">
                    Status
                </label>

                <select class="form-select">

                    <option selected>
                        Aktif
                    </option>

                    <option>
                        Nonaktif
                    </option>

                </select>

            </div>


            <button
                type="button"
                class="btn btn-primary"
            >
                Simpan Perubahan
            </button>

        </div>

    </div>

</div>

@endsection