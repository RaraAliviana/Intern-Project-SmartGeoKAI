@extends('layouts.app')

@section('title', 'Tambah Petugas')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-4">
        Tambah Petugas
    </h2>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="mb-3">

                <label class="form-label">
                    Nama Lengkap
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="Nama lengkap"
                >

            </div>


            <div class="mb-3">

                <label class="form-label">
                    Username
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="Username"
                >

            </div>


            <div class="mb-3">

                <label class="form-label">
                    NIP
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="NIP"
                >

            </div>


            <button
                type="button"
                class="btn btn-primary"
            >
                Simpan
            </button>

        </div>

    </div>

</div>

@endsection