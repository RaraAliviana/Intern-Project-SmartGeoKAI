@extends('layouts.app')

@section('title', 'Petugas')

@section('content')

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="title-1 mb-1">
                Petugas
            </h2>

            <p class="text-muted mb-0">
                Daftar petugas SmartGeoKAI.
            </p>

        </div>


        <a
            href="{{ route('admin.users.create') }}"
            class="btn btn-primary"
        >

            <i class="fa-solid fa-plus me-1"></i>

            Tambah Petugas

        </a>

    </div>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle">

                    <thead>

                        <tr>

                            <th>No</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>NIP</th>
                            <th>Status</th>
                            <th>Aksi</th>

                        </tr>

                    </thead>


                    <tbody>

                        @for($i = 1; $i <= 5; $i++)

                        <tr>

                            <td>
                                {{ $i }}
                            </td>

                            <td>
                                Petugas Demo {{ $i }}
                            </td>

                            <td>
                                petugas{{ $i }}
                            </td>

                            <td>
                                1989010120200{{ $i }}
                            </td>

                            <td>

                                <span class="badge bg-success">
                                    Aktif
                                </span>

                            </td>

                            <td>

                                <a
                                    href="{{ route('admin.users.edit', $i) }}"
                                    class="btn btn-sm btn-outline-primary"
                                >

                                    <i class="fa-solid fa-pen"></i>

                                </a>

                            </td>

                        </tr>

                        @endfor

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

@endsection