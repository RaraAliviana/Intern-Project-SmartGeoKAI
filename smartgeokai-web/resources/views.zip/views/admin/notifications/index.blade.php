@extends('layouts.app')

@section('title', 'Notifikasi')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-1">
        Notifikasi
    </h2>

    <p class="text-muted mb-4">
        Informasi dan pemberitahuan sistem.
    </p>


    <div class="card border-0 shadow-sm">

        <div class="card-body">


            <div class="d-flex gap-3 border-bottom py-3">

                <i class="fa-solid fa-bell text-primary mt-1"></i>

                <div>

                    <strong>
                        Data aset diperbarui
                    </strong>

                    <p class="text-muted mb-1">
                        Data aset 06.01.00001 telah diperbarui.
                    </p>

                    <small class="text-muted">
                        10 menit yang lalu
                    </small>

                </div>

            </div>


            <div class="d-flex gap-3 border-bottom py-3">

                <i class="fa-solid fa-circle-check text-success mt-1"></i>

                <div>

                    <strong>
                        Approval berhasil
                    </strong>

                    <p class="text-muted mb-1">
                        Aset berhasil disetujui.
                    </p>

                    <small class="text-muted">
                        1 jam yang lalu
                    </small>

                </div>

            </div>


            <div class="d-flex gap-3 py-3">

                <i class="fa-solid fa-user-plus text-primary mt-1"></i>

                <div>

                    <strong>
                        Petugas baru
                    </strong>

                    <p class="text-muted mb-1">
                        Petugas baru ditambahkan ke sistem.
                    </p>

                    <small class="text-muted">
                        2 jam yang lalu
                    </small>

                </div>

            </div>


        </div>

    </div>

</div>

@endsection