@extends('layouts.app')

@section('title', 'Log Audit')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-1">
        Log Audit
    </h2>

    <p class="text-muted mb-4">
        Riwayat aktivitas pengguna dalam sistem.
    </p>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover">

                    <thead>

                        <tr>

                            <th>Waktu</th>
                            <th>Pengguna</th>
                            <th>Aktivitas</th>
                            <th>Data</th>

                        </tr>

                    </thead>


                    <tbody>

                        <tr>

                            <td>
                                08 Agustus 2026 09:00
                            </td>

                            <td>
                                Admin
                            </td>

                            <td>
                                Memperbarui data aset
                            </td>

                            <td>
                                06.01.00001
                            </td>

                        </tr>


                        <tr>

                            <td>
                                08 Agustus 2026 08:30
                            </td>

                            <td>
                                Petugas 01
                            </td>

                            <td>
                                Menambahkan aset
                            </td>

                            <td>
                                06.01.00002
                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

@endsection