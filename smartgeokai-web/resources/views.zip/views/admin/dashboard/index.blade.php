@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')

<div class="container-fluid">

    {{-- Page Header --}}

    <div class="row mb-4">

        <div class="col-12">

            <h2 class="title-1">
                Dashboard
            </h2>

            <p class="text-muted">
                Ringkasan pengelolaan aset SmartGeoKAI.
            </p>

        </div>

    </div>


    {{-- =========================================================
         STATISTICS
    ========================================================== --}}

    <div class="row">


        {{-- Total Aset --}}

        <div class="col-md-6 col-xl-3 mb-4">

            <div class="card border-0 shadow-sm">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <p class="text-muted mb-1">
                                Total Aset
                            </p>

                            <h3 class="mb-0">
                                1.248
                            </h3>

                        </div>

                        <i
                            class="fa-solid fa-boxes-stacked text-primary"
                            style="font-size: 32px;"
                        ></i>

                    </div>

                </div>

            </div>

        </div>


        {{-- Aset Aktif --}}

        <div class="col-md-6 col-xl-3 mb-4">

            <div class="card border-0 shadow-sm">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <p class="text-muted mb-1">
                                Aset Aktif
                            </p>

                            <h3 class="mb-0">
                                1.105
                            </h3>

                        </div>

                        <i
                            class="fa-solid fa-circle-check text-success"
                            style="font-size: 32px;"
                        ></i>

                    </div>

                </div>

            </div>

        </div>


        {{-- Perlu Pemeriksaan --}}

        <div class="col-md-6 col-xl-3 mb-4">

            <div class="card border-0 shadow-sm">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <p class="text-muted mb-1">
                                Perlu Pemeriksaan
                            </p>

                            <h3 class="mb-0">
                                86
                            </h3>

                        </div>

                        <i
                            class="fa-solid fa-triangle-exclamation text-warning"
                            style="font-size: 32px;"
                        ></i>

                    </div>

                </div>

            </div>

        </div>


        {{-- Approval --}}

        <div class="col-md-6 col-xl-3 mb-4">

            <div class="card border-0 shadow-sm">

                <div class="card-body">

                    <div class="d-flex justify-content-between">

                        <div>

                            <p class="text-muted mb-1">
                                Menunggu Approval
                            </p>

                            <h3 class="mb-0">
                                12
                            </h3>

                        </div>

                        <i
                            class="fa-solid fa-clock text-danger"
                            style="font-size: 32px;"
                        ></i>

                    </div>

                </div>

            </div>

        </div>

    </div>


    {{-- =========================================================
         MAIN
    ========================================================== --}}

    <div class="row">


        {{-- Map --}}

        <div class="col-lg-8 mb-4">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white">

                    <div class="d-flex justify-content-between align-items-center">

                        <h5 class="mb-0">
                            Sebaran Aset
                        </h5>

                        <a
                            href="{{ route('admin.assets.index') }}"
                            class="btn btn-primary btn-sm"
                        >
                            Lihat Peta
                        </a>

                    </div>

                </div>

                <div class="card-body p-0">

                    <div class="dummy-map">

                        <div class="text-center text-muted">

                            <i
                                class="fa-solid fa-map-location-dot"
                                style="font-size: 50px;"
                            ></i>

                            <p class="mt-3 mb-0">
                                Peta aset akan diintegrasikan kemudian.
                            </p>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- Activity --}}

        <div class="col-lg-4 mb-4">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white">

                    <h5 class="mb-0">
                        Aktivitas Terbaru
                    </h5>

                </div>

                <div class="card-body">

                    <div class="activity-item">

                        <i class="fa-solid fa-pen text-primary"></i>

                        <div>

                            <strong>
                                Data aset diperbarui
                            </strong>

                            <small>
                                10 menit yang lalu
                            </small>

                        </div>

                    </div>


                    <div class="activity-item">

                        <i class="fa-solid fa-user-plus text-success"></i>

                        <div>

                            <strong>
                                Petugas baru ditambahkan
                            </strong>

                            <small>
                                1 jam yang lalu
                            </small>

                        </div>

                    </div>


                    <div class="activity-item">

                        <i class="fa-solid fa-check text-success"></i>

                        <div>

                            <strong>
                                Aset disetujui
                            </strong>

                            <small>
                                2 jam yang lalu
                            </small>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

@endsection