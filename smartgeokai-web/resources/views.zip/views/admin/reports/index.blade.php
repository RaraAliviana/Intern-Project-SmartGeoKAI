@extends('layouts.app')

@section('title', 'Laporan')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-1">
        Laporan
    </h2>

    <p class="text-muted mb-4">
        Laporan dan rekapitulasi data aset.
    </p>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="row">

                <div class="col-md-4 mb-3">

                    <label class="form-label">
                        Periode
                    </label>

                    <select class="form-select">

                        <option>
                            Bulan Ini
                        </option>

                        <option>
                            Bulan Lalu
                        </option>

                        <option>
                            Tahun Ini
                        </option>

                    </select>

                </div>


                <div class="col-md-4 mb-3">

                    <label class="form-label">
                        Status
                    </label>

                    <select class="form-select">

                        <option>
                            Semua
                        </option>

                        <option>
                            Aktif
                        </option>

                        <option>
                            Rusak
                        </option>

                    </select>

                </div>

            </div>


            <hr>


            <button
                type="button"
                class="btn btn-success"
            >

                <i class="fa-solid fa-file-excel me-1"></i>

                Export Excel

            </button>


            <button
                type="button"
                class="btn btn-danger"
            >

                <i class="fa-solid fa-file-pdf me-1"></i>

                Export PDF

            </button>

        </div>

    </div>

</div>

@endsection