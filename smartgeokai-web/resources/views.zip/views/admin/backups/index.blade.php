@extends('layouts.app')

@section('title', 'Backup')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-1">
        Backup Database
    </h2>

    <p class="text-muted mb-4">
        Pengelolaan pencadangan database SmartGeoKAI.
    </p>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="text-center py-5">

                <i
                    class="fa-solid fa-database text-primary"
                    style="font-size: 50px;"
                ></i>

                <h5 class="mt-3">
                    Backup Database
                </h5>

                <p class="text-muted">
                    Fitur backup akan dihubungkan kemudian.
                </p>

                <button
                    type="button"
                    class="btn btn-primary"
                >

                    <i class="fa-solid fa-download me-1"></i>

                    Buat Backup

                </button>

            </div>

        </div>

    </div>

</div>

@endsection