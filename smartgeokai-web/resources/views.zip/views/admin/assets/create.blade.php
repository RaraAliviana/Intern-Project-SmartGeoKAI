@extends('layouts.app')

@section('title', 'Tambah Aset')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-4">
        Tambah Aset
    </h2>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="mb-3">

                <label class="form-label">
                    ID Aset
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="Contoh: 06.01.00001"
                >

            </div>


            <div class="mb-3">

                <label class="form-label">
                    Nama Aset
                </label>

                <input
                    type="text"
                    class="form-control"
                    placeholder="Masukkan nama aset"
                >

            </div>


            <div class="mb-3">

                <label class="form-label">
                    Jenis Aset
                </label>

                <select class="form-select">

                    <option selected>
                        Pilih jenis aset
                    </option>

                    <option>
                        Tanah
                    </option>

                    <option>
                        Bangunan
                    </option>

                    <option>
                        Kendaraan
                    </option>

                    <option>
                        Peralatan
                    </option>

                </select>

            </div>


            <div class="mb-3">

                <label class="form-label">
                    Alamat
                </label>

                <textarea
                    class="form-control"
                    rows="3"
                    placeholder="Alamat aset"
                ></textarea>

            </div>


            <div>

                <button
                    type="button"
                    class="btn btn-primary"
                >
                    Simpan
                </button>

                <a
                    href="{{ route('admin.assets.index') }}"
                    class="btn btn-secondary"
                >
                    Batal
                </a>

            </div>

        </div>

    </div>

</div>

@endsection