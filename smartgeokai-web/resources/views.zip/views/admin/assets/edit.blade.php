@extends('layouts.app')

@section('title', 'Edit Aset')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-4">
        Edit Aset
    </h2>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="mb-3">

                <label class="form-label">
                    ID Aset
                </label>

                <input
                    type="text"
                    class="form-control"
                    value="06.01.00001"
                >

            </div>


            <div class="mb-3">

                <label class="form-label">
                    Nama Aset
                </label>

                <input
                    type="text"
                    class="form-control"
                    value="Gedung Perkantoran"
                >

            </div>


            <div class="mb-3">

                <label class="form-label">
                    Status
                </label>

                <select class="form-select">

                    <option selected>
                        Aktif
                    </option>

                    <option>
                        Rusak
                    </option>

                    <option>
                        Tidak Aktif
                    </option>

                </select>

            </div>


            <button
                type="button"
                class="btn btn-primary"
            >
                Simpan Perubahan
            </button>

        </div>

    </div>

</div>

@endsection