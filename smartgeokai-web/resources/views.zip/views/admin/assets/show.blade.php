@extends('layouts.app')

@section('title', 'Detail Aset')

@section('content')

<div class="container-fluid">

    <div class="mb-4">

        <a
            href="{{ route('admin.assets.index') }}"
            class="text-decoration-none"
        >

            <i class="fa-solid fa-arrow-left"></i>

            Kembali ke Aset

        </a>

    </div>


    <div class="card border-0 shadow-sm">

        <div class="card-header bg-white">

            <h5 class="mb-0">
                Detail Aset
            </h5>

        </div>

        <div class="card-body">

            <div class="row">

                <div class="col-md-6">

                    <p>
                        <strong>ID Aset</strong><br>
                        06.01.00001
                    </p>

                    <p>
                        <strong>Nama Aset</strong><br>
                        Gedung Perkantoran
                    </p>

                    <p>
                        <strong>Jenis Aset</strong><br>
                        Bangunan
                    </p>

                </div>


                <div class="col-md-6">

                    <p>
                        <strong>Status</strong><br>

                        <span class="badge bg-success">
                            Aktif
                        </span>

                    </p>

                    <p>
                        <strong>Wilayah</strong><br>
                        Kabupaten Ngawi
                    </p>

                    <p>
                        <strong>Petugas</strong><br>
                        Petugas Demo
                    </p>

                </div>

            </div>


            <hr>


            <a
                href="{{ route('admin.assets.edit', 1) }}"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-pen"></i>

                Edit

            </a>

        </div>

    </div>

</div>

@endsection