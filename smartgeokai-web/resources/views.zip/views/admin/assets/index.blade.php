@extends('layouts.app')

@section('title', 'Peta & Aset')

@section('content')

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h2 class="title-1 mb-1">
                Peta & Aset
            </h2>

            <p class="text-muted mb-0">
                Daftar dan lokasi aset.
            </p>

        </div>

        <a
            href="{{ route('admin.assets.create') }}"
            class="btn btn-primary"
        >

            <i class="fa-solid fa-plus me-1"></i>

            Tambah Aset

        </a>

    </div>


    <div class="row">


        {{-- Map --}}

        <div class="col-lg-8 mb-4">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white">

                    <h5 class="mb-0">
                        Peta Aset
                    </h5>

                </div>

                <div class="card-body p-0">

                    <div class="dummy-map">

                        <div class="text-center text-muted">

                            <i
                                class="fa-solid fa-map"
                                style="font-size: 50px;"
                            ></i>

                            <p class="mt-3 mb-0">
                                Integrasi peta akan dikerjakan kemudian.
                            </p>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- Asset List --}}

        <div class="col-lg-4 mb-4">

            <div class="card border-0 shadow-sm">

                <div class="card-header bg-white">

                    <h5 class="mb-0">
                        Daftar Aset
                    </h5>

                </div>

                <div class="card-body">

                    @for($i = 1; $i <= 5; $i++)

                        <div class="border-bottom pb-3 mb-3">

                            <div class="d-flex justify-content-between">

                                <strong>
                                    06.01.0000{{ $i }}
                                </strong>

                                <span class="badge bg-success">
                                    Aktif
                                </span>

                            </div>

                            <small class="text-muted">
                                Aset Infrastruktur {{ $i }}
                            </small>

                            <div class="mt-2">

                                <a
                                    href="{{ route('admin.assets.show', $i) }}"
                                    class="btn btn-sm btn-outline-primary"
                                >
                                    Detail
                                </a>

                            </div>

                        </div>

                    @endfor

                </div>

            </div>

        </div>

    </div>

</div>

@endsection