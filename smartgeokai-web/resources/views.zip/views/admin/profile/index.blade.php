@extends('layouts.app')

@section('title', 'Profil')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-1">
        Profil
    </h2>

    <p class="text-muted mb-4">
        Informasi pengguna.
    </p>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="row align-items-center">

                <div class="col-md-3 text-center">

                    <img
                        src="{{ asset('images/icon/avatar-01.jpg') }}"
                        alt="Avatar"
                        width="120"
                        height="120"
                        class="rounded-circle"
                    >

                </div>


                <div class="col-md-9">

                    <h4>
                        Admin SmartGeoKAI
                    </h4>

                    <p class="text-muted">
                        Administrator
                    </p>

                    <hr>

                    <p class="mb-2">

                        <strong>
                            Username:
                        </strong>

                        admin

                    </p>


                    <p class="mb-2">

                        <strong>
                            NIP:
                        </strong>

                        19890101202001

                    </p>


                    <p class="mb-0">

                        <strong>
                            Status:
                        </strong>

                        <span class="badge bg-success">
                            Aktif
                        </span>

                    </p>

                </div>

            </div>

        </div>

    </div>

</div>

@endsection