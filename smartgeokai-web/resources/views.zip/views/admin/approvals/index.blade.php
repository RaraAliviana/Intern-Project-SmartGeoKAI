@extends('layouts.app')

@section('title', 'Approval')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-1">
        Approval Aset
    </h2>

    <p class="text-muted mb-4">
        Daftar aset yang menunggu persetujuan.
    </p>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="table-responsive">

                <table class="table table-hover align-middle">

                    <thead>

                        <tr>

                            <th>ID Aset</th>
                            <th>Nama Aset</th>
                            <th>Petugas</th>
                            <th>Tanggal</th>
                            <th>Status</th>
                            <th>Aksi</th>

                        </tr>

                    </thead>


                    <tbody>

                        <tr>

                            <td>
                                06.01.00001
                            </td>

                            <td>
                                Gedung Perkantoran
                            </td>

                            <td>
                                Petugas Demo
                            </td>

                            <td>
                                08 Agustus 2026
                            </td>

                            <td>

                                <span class="badge bg-warning text-dark">
                                    Menunggu
                                </span>

                            </td>

                            <td>

                                <button
                                    type="button"
                                    class="btn btn-sm btn-success"
                                >
                                    Setujui
                                </button>

                                <button
                                    type="button"
                                    class="btn btn-sm btn-danger"
                                >
                                    Tolak
                                </button>

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

@endsection