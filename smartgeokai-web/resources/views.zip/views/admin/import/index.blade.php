@extends('layouts.app')

@section('title', 'Import Data')

@section('content')

<div class="container-fluid">

    <h2 class="title-1 mb-1">
        Import Data
    </h2>

    <p class="text-muted mb-4">
        Import data aset menggunakan file CSV.
    </p>


    <div class="card border-0 shadow-sm">

        <div class="card-body">

            <div class="mb-4">

                <label class="form-label">
                    Pilih File CSV
                </label>

                <input
                    type="file"
                    class="form-control"
                    accept=".csv"
                >

            </div>


            <button
                type="button"
                class="btn btn-primary"
            >

                <i class="fa-solid fa-upload me-1"></i>

                Import Data

            </button>

        </div>

    </div>

</div>

@endsection