<aside class="menu-sidebar" id="main-sidebar">

    {{-- Logo --}}
    <div class="logo">

        <a
            href="{{ route('admin.dashboard') }}"
            class="logo-link"
        >

            <span class="logo-mark">
                S
            </span>

            <span class="logo-text">
                SmartGeoKAI
            </span>

        </a>

    </div>


    {{-- Menu --}}
    <div class="menu-sidebar__content">

        <nav class="navbar-sidebar">

            <ul class="list-unstyled navbar__list">

                {{-- Dashboard --}}
                <li class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">

                    <a href="{{ route('admin.dashboard') }}">

                        <i class="fa-solid fa-gauge-high"></i>

                        <span>
                            Dashboard
                        </span>

                    </a>

                </li>


                {{-- Peta & Aset --}}
                <li class="{{ request()->routeIs('admin.assets.*') ? 'active' : '' }}">

                    <a href="{{ route('admin.assets.index') }}">

                        <i class="fa-solid fa-map-location-dot"></i>

                        <span>
                            Peta & Aset
                        </span>

                    </a>

                </li>


                {{-- Petugas --}}
                <li class="{{ request()->routeIs('admin.users.*') ? 'active' : '' }}">

                    <a href="{{ route('admin.users.index') }}">

                        <i class="fa-solid fa-users"></i>

                        <span>
                            Petugas
                        </span>

                    </a>

                </li>


                {{-- Approval --}}
                <li class="{{ request()->routeIs('admin.approvals.*') ? 'active' : '' }}">

                    <a href="{{ route('admin.approvals.index') }}">

                        <i class="fa-solid fa-circle-check"></i>

                        <span>
                            Approval
                        </span>

                    </a>

                </li>


                {{-- Laporan --}}
                <li class="{{ request()->routeIs('admin.reports.*') ? 'active' : '' }}">

                    <a href="{{ route('admin.reports.index') }}">

                        <i class="fa-solid fa-chart-column"></i>

                        <span>
                            Laporan
                        </span>

                    </a>

                </li>


                {{-- Import --}}
                <li class="{{ request()->routeIs('admin.import.*') ? 'active' : '' }}">

                    <a href="{{ route('admin.import.index') }}">

                        <i class="fa-solid fa-file-import"></i>

                        <span>
                            Import Data
                        </span>

                    </a>

                </li>


                {{-- Notifikasi --}}
                <li class="{{ request()->routeIs('admin.notifications.*') ? 'active' : '' }}">

                    <a href="{{ route('admin.notifications.index') }}">

                        <i class="fa-solid fa-bell"></i>

                        <span>
                            Notifikasi
                        </span>

                    </a>

                </li>


                {{-- Log Audit --}}
                <li class="{{ request()->routeIs('admin.log-audit.*') ? 'active' : '' }}">

                    <a href="{{ route('admin.log-audit.index') }}">

                        <i class="fa-solid fa-clock-rotate-left"></i>

                        <span>
                            Log Audit
                        </span>

                    </a>

                </li>


                {{-- Backup --}}
                <li class="{{ request()->routeIs('admin.backup.*') ? 'active' : '' }}">

                    <a href="{{ route('admin.backup.index') }}">

                        <i class="fa-solid fa-database"></i>

                        <span>
                            Backup
                        </span>

                    </a>

                </li>

            </ul>

        </nav>

    </div>

</aside>