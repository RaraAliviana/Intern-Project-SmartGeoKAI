<header class="header-desktop">

    <div class="section__content section__content--p30">

        <div class="container-fluid">

            <div class="header-wrap">

                {{-- Toggle Sidebar --}}
                <button
                    type="button"
                    class="btn btn-link sidebar-toggle"
                    id="sidebarToggle"
                    aria-label="Toggle sidebar"
                >

                    <i class="fa-solid fa-bars"></i>

                </button>


                {{-- Search --}}
                <form
                    class="form-header"
                    onsubmit="return false;"
                >

                    <input
                        type="search"
                        class="form-control"
                        placeholder="Cari aset..."
                    >

                    <button type="submit">

                        <i class="fa-solid fa-search"></i>

                    </button>

                </form>


                {{-- Right --}}
                <div class="header-button">

                    {{-- Notification --}}
                    <a
                        href="{{ route('admin.notifications.index') }}"
                        class="header-icon"
                        title="Notifikasi"
                    >

                        <i class="fa-solid fa-bell"></i>

                    </a>


                    {{-- User --}}
                    <div class="account-wrap">

                        <div class="account-item">

                            <div class="image">

                                <img
                                    src="{{ asset('images/icon/avatar-01.jpg') }}"
                                    alt="User"
                                >

                            </div>

                            <div class="content">

                                <span>
                                    {{ auth()->user()->full_name ?? 'Admin' }}
                                </span>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</header>