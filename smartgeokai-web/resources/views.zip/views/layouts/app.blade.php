<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>
        SmartGeoKAI - @yield('title', 'Dashboard')
    </title>

    {{-- Font --}}
    <link href="{{ asset('css/font-face.css') }}" rel="stylesheet">

    {{-- Font Awesome --}}
    <link
        href="{{ asset('vendor/fontawesome-7.3.1/css/all.min.css') }}"
        rel="stylesheet"
    >

    {{-- Bootstrap --}}
    <link
        href="{{ asset('vendor/bootstrap-5.3.8.min.css') }}"
        rel="stylesheet"
    >

    {{-- Hamburger --}}
    <link
        href="{{ asset('vendor/css-hamburgers/hamburgers.min.css') }}"
        rel="stylesheet"
    >

    {{-- CoolAdmin --}}
    <link
        href="{{ asset('css/theme.css') }}"
        rel="stylesheet"
    >

    {{-- Custom CSS --}}
    <link
        href="{{ asset('css/app.css') }}"
        rel="stylesheet"
    >

    @stack('styles')

</head>

<body class="app">

    {{-- Sidebar --}}
    @include('layouts.sidebar')

    {{-- Page --}}
    <div class="page-container">

        {{-- Header --}}
        @include('layouts.header')

        {{-- Content --}}
        <div class="main-content">

            <div class="section__content section__content--p30">

                @yield('content')

            </div>

        </div>

    </div>

    {{-- JavaScript --}}
    <script src="{{ asset('vendor/bootstrap-5.3.8.bundle.min.js') }}"></script>

    <script src="{{ asset('js/main-vanilla.js') }}"></script>

    @stack('scripts')

</body>

</html>